<?php
/**
 * Name:  Footer style 04
 **/
?>
<footer class="footer style4">
    <div class="container">
        <?php the_content(); ?>
    </div>
</footer>