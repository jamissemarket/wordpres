<?php
/**
 * Name:  Footer style 01
 **/
?>
<footer class="footer style1">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>